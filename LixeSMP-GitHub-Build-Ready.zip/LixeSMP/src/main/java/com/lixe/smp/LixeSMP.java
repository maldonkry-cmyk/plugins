package com.lixe.smp;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.bukkit.WorldCreator;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class LixeSMP extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey itemKey, duelPearlKey;
    private final Map<UUID, Long> rtpCooldowns = new HashMap<>();
    private final Map<UUID, Long> dashCooldowns = new HashMap<>();
    private final Map<UUID, Location> returnLocations = new HashMap<>();
    private final Set<UUID> duelists = new HashSet<>();
    private UUID duelA, duelB;
    private long duelEndsAt;
    private World duelWorld;

    @Override public void onEnable() {
        saveDefaultConfig();
        itemKey = new NamespacedKey(this, "lixe_item");
        duelPearlKey = new NamespacedKey(this, "lixe_duel_pearl");
        loadCooldowns();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("lixe")).setExecutor(this);
        createDuelWorld();
        registerAltarRecipe();
        Bukkit.getScheduler().runTaskTimer(this, this::checkDuelTimeout, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::applyHeldWeaponEffects, 20L, 20L);
        getLogger().info("LixeSMP enabled for Paper 1.21.x");
    }

    @Override public void onDisable() { saveCooldowns(); }

    private void createDuelWorld() {
        World existing = Bukkit.getWorld("LixeDuel");
        duelWorld = existing != null ? existing : Bukkit.createWorld(new WorldCreator("LixeDuel").environment(World.Environment.NORMAL));
        if (duelWorld == null) { getLogger().severe("Could not create LixeDuel world; Duel Pearl will be unavailable."); return; }
        duelWorld.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        duelWorld.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        duelWorld.setStorm(false); duelWorld.setThundering(false);
        buildArena();
    }

    private void buildArena() {
        if (duelWorld == null) return;
        int minX=-8, maxX=18, minZ=-8, maxZ=8, floorY=100;
        for (int x=minX; x<=maxX; x++) for (int z=minZ; z<=maxZ; z++) {
            duelWorld.getBlockAt(x, floorY, z).setType(Material.OBSIDIAN, false);
            for (int y=floorY+1; y<=floorY+6; y++) {
                if (x==minX || x==maxX || z==minZ || z==maxZ) duelWorld.getBlockAt(x,y,z).setType(Material.GLASS, false);
                else duelWorld.getBlockAt(x,y,z).setType(Material.AIR, false);
            }
        }
        duelWorld.setSpawnLocation(4, floorY+1, 0);
    }

    private ItemStack customItem(String id) {
        Material material; String name; List<String> lore = new ArrayList<>();
        switch (id.toLowerCase(Locale.ROOT)) {
            case "rtp_pearl" -> { material=Material.ENDER_PEARL; name="§d§lRTP Pearl"; lore.add("§7Right-click to teleport to a random safe place."); lore.add("§5Cooldown: 12 hours"); }
            case "duel_pearl" -> { material=Material.ENDER_PEARL; name="§5§lDuel Pearl"; lore.add("§7Throw at a player to challenge them to a duel."); lore.add("§dArena is protected • 120 minutes"); }
            case "sift_sword" -> { material=Material.NETHERITE_SWORD; name="§b§lSift Sword"; lore.add("§7Right-click to dash forward."); lore.add("§bPermanent Speed II while held"); lore.add("§3Ability: Dash"); }
            case "infuse_axe" -> { material=Material.NETHERITE_AXE; name="§6§lInfuse Axe"; lore.add("§7Fire Resistance while held."); lore.add("§6Sharpness VI • Cannot be removed normally"); }
            case "altar_sword" -> { material=Material.NETHERITE_SWORD; name="§5§l✦ Altar Sword ✦"; lore.add("§dThe ultimate weapon of LixeSMP."); lore.add("§5Forged from all four relics, 2 Maces and a Dragon Egg."); lore.add("§dSpeed II • Dash • Fire Resistance"); }
            default -> { return null; }
        }
        ItemStack item = new ItemStack(material); ItemMeta meta=item.getItemMeta();
        meta.setDisplayName(name); meta.setLore(lore); meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, id.toLowerCase(Locale.ROOT));
        meta.setCustomModelData(switch(id.toLowerCase(Locale.ROOT)){case "rtp_pearl"->7101;case "duel_pearl"->7102;case "sift_sword"->7103;case "infuse_axe"->7104;case "altar_sword"->7105;default->7100;});
        if (id.equalsIgnoreCase("sift_sword") || id.equalsIgnoreCase("altar_sword")) meta.addEnchant(Enchantment.SHARPNESS, id.equalsIgnoreCase("altar_sword") ? 8 : 5, true);
        if (id.equalsIgnoreCase("infuse_axe")) meta.addEnchant(Enchantment.SHARPNESS, 6, true);
        item.setItemMeta(meta); return item;
    }

    private String customId(ItemStack item) {
        if (item==null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
    }

    private void registerAltarRecipe() {
        NamespacedKey recipeKey = new NamespacedKey(this, "altar_sword_recipe");
        Bukkit.removeRecipe(recipeKey);
        ShapelessRecipe recipe = new ShapelessRecipe(recipeKey, customItem("altar_sword"));
        recipe.addIngredient(new RecipeChoice.ExactChoice(customItem("rtp_pearl")));
        recipe.addIngredient(new RecipeChoice.ExactChoice(customItem("duel_pearl")));
        recipe.addIngredient(new RecipeChoice.ExactChoice(customItem("sift_sword")));
        recipe.addIngredient(new RecipeChoice.ExactChoice(customItem("infuse_axe")));
        recipe.addIngredient(Material.MACE); recipe.addIngredient(Material.MACE); recipe.addIngredient(Material.DRAGON_EGG);
        Bukkit.addRecipe(recipe);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length==1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("lixe.admin")) { sender.sendMessage("§cNo permission."); return true; }
            reloadConfig(); registerAltarRecipe(); sender.sendMessage("§aLixeSMP config reloaded."); return true;
        }
        if (args.length<3 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage("§eUsage: /lixe give <player> <rtp_pearl|duel_pearl|sift_sword|infuse_axe|altar_sword>");
            sender.sendMessage("§eAliases: rtp, duel, sift, infuse, altar"); return true;
        }
        if (!sender.hasPermission("lixe.admin")) { sender.sendMessage("§cNo permission."); return true; }
        Player target=Bukkit.getPlayerExact(args[1]); if(target==null){sender.sendMessage("§cPlayer not online.");return true;}
        String id=switch(args[2].toLowerCase(Locale.ROOT)){case "rtp"->"rtp_pearl";case "duel"->"duel_pearl";case "sift"->"sift_sword";case "infuse"->"infuse_axe";case "altar"->"altar_sword";default->args[2].toLowerCase(Locale.ROOT);};
        ItemStack item=customItem(id); if(item==null){sender.sendMessage("§cUnknown item.");return true;}
        Map<Integer,ItemStack> leftover=target.getInventory().addItem(item); leftover.values().forEach(it->target.getWorld().dropItemNaturally(target.getLocation(),it));
        sender.sendMessage("§aGave " + id + " to " + target.getName()+"."); return true;
    }

    @EventHandler public void onInteract(PlayerInteractEvent event) {
        if (event.getHand()!=EquipmentSlot.HAND) return;
        Player p=event.getPlayer(); ItemStack item=event.getItem(); String id=customId(item);
        if (id==null || !(event.getAction().isRightClick())) return;
        if (id.equals("rtp_pearl")) {
            event.setCancelled(true);
            long now=System.currentTimeMillis(), cooldown=getConfig().getLong("rtp-cooldown-hours",12)*3600000L;
            long ready=rtpCooldowns.getOrDefault(p.getUniqueId(),0L);
            if(now<ready){p.sendMessage("§cRTP Pearl ready in §e"+formatDuration(ready-now)+"§c.");return;}
            Location destination=findSafeLocation(p.getWorld());
            if(destination==null){p.sendMessage("§cCould not find a safe random location. Try again.");return;}
            consumeOne(p, EquipmentSlot.HAND); p.teleport(destination); p.getWorld().playSound(destination,Sound.ENTITY_ENDERMAN_TELEPORT,1f,1f); p.sendMessage("§d✦ You have been randomly teleported!");
            rtpCooldowns.put(p.getUniqueId(),now+cooldown); saveCooldowns();
        } else if(id.equals("duel_pearl")) {
            event.setCancelled(true);
            if(duelA!=null){p.sendMessage("§cA duel is already active.");return;}
            consumeOne(p,EquipmentSlot.HAND);
            EnderPearl projectile=p.launchProjectile(EnderPearl.class); projectile.getPersistentDataContainer().set(duelPearlKey,PersistentDataType.BYTE,(byte)1);
            p.sendMessage("§5Throw the Duel Pearl at a player to challenge them!");
        } else if (id.equals("sift_sword") || id.equals("altar_sword")) {
            event.setCancelled(true);
            long now=System.currentTimeMillis(), cd=getConfig().getLong("dash-cooldown-seconds",8)*1000L;
            long ready=dashCooldowns.getOrDefault(p.getUniqueId(),0L);
            if(now<ready){p.sendMessage("§cDash cooldown: "+((ready-now+999)/1000)+"s");return;}
            Vector direction=p.getLocation().getDirection().normalize().multiply(getConfig().getDouble("dash-power",1.8));
            direction.setY(Math.max(0.35,direction.getY()+0.25)); p.setVelocity(direction); p.getWorld().spawnParticle(Particle.CLOUD,p.getLocation(),24,0.35,0.25,0.35,0.03); p.getWorld().playSound(p.getLocation(),Sound.ENTITY_ENDER_DRAGON_FLAP,0.6f,1.6f);
            dashCooldowns.put(p.getUniqueId(),now+cd);
        }
    }

    @EventHandler public void onProjectileHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof EnderPearl pearl) || pearl.getPersistentDataContainer().get(duelPearlKey,PersistentDataType.BYTE)==null) return;
        if (!(pearl.getShooter() instanceof Player challenger) || !(event.getHitEntity() instanceof Player target)) { if(pearl.getShooter() instanceof Player p) p.sendMessage("§cThe Duel Pearl must hit a player."); return; }
        startDuel(challenger,target);
    }

    private void startDuel(Player a, Player b) {
        if(a.equals(b) || duelA!=null || duelWorld==null){a.sendMessage("§cDuel unavailable or another duel is active.");return;}
        if(a.isDead()||b.isDead()||!a.isOnline()||!b.isOnline()) return;
        returnLocations.put(a.getUniqueId(),a.getLocation().clone()); returnLocations.put(b.getUniqueId(),b.getLocation().clone());
        duelA=a.getUniqueId(); duelB=b.getUniqueId(); duelists.add(duelA); duelists.add(duelB);
        duelEndsAt=System.currentTimeMillis()+getConfig().getLong("duel-duration-minutes",120)*60000L;
        a.setHealth(a.getMaxHealth()); b.setHealth(b.getMaxHealth()); a.setFoodLevel(20); b.setFoodLevel(20);
        a.teleport(new Location(duelWorld,0.5,101,0.5,90,0)); b.teleport(new Location(duelWorld,10.5,101,0.5,-90,0));
        a.sendMessage("§5§lDUEL STARTED! §dFight!"); b.sendMessage("§5§lDUEL STARTED! §dFight!");
        Bukkit.broadcastMessage("§5⚔ §d"+a.getName()+" §5vs §d"+b.getName()+" §5— duel started!");
    }

    @EventHandler public void onDamage(EntityDamageByEntityEvent event) {
        if(event.getEntity() instanceof Player victim && duelWorld!=null && victim.getWorld().equals(duelWorld)) {
            Player attacker=null;
            if(event.getDamager() instanceof Player p) attacker=p;
            else if(event.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player p) attacker=p;
            if(attacker==null || !duelists.contains(attacker.getUniqueId()) || !duelists.contains(victim.getUniqueId())) event.setCancelled(true);
        }
    }

    @EventHandler public void onDeath(EntityDeathEvent event) {
        if(event.getEntity() instanceof Player p && duelists.contains(p.getUniqueId())) {
            UUID winner=p.getUniqueId().equals(duelA)?duelB:duelA;
            Player w=Bukkit.getPlayer(winner); finishDuel(w,"§aWinner: "+(w==null?"opponent":w.getName()));
        }
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        Player p=event.getPlayer(); if(duelists.contains(p.getUniqueId())) { UUID winner=p.getUniqueId().equals(duelA)?duelB:duelA; finishDuel(Bukkit.getPlayer(winner),"§cDuel ended because a player left."); }
    }

    @EventHandler public void onBlockBreak(BlockBreakEvent e) { if(duelWorld!=null && e.getBlock().getWorld().equals(duelWorld)) e.setCancelled(true); }
    @EventHandler public void onBlockPlace(BlockPlaceEvent e) { if(duelWorld!=null && e.getBlock().getWorld().equals(duelWorld)) e.setCancelled(true); }
    @EventHandler public void onBucket(PlayerBucketEmptyEvent e) { if(duelWorld!=null && e.getBlock().getWorld().equals(duelWorld)) e.setCancelled(true); }
    @EventHandler public void onBucketFill(PlayerBucketFillEvent e) { if(duelWorld!=null && e.getBlock().getWorld().equals(duelWorld)) e.setCancelled(true); }
    @EventHandler public void onMove(PlayerMoveEvent e) {
        if(duelWorld!=null && e.getPlayer().getWorld().equals(duelWorld) && !duelists.contains(e.getPlayer().getUniqueId())) {
            Location to=e.getTo();
            if(to!=null && (Math.abs(to.getX()-4.5)>0.5 || Math.abs(to.getY()-101)>1.0 || Math.abs(to.getZ()-0.5)>0.5)) {
                e.getPlayer().teleport(new Location(duelWorld,4.5,101,0.5));
                e.getPlayer().sendMessage("§cThis world is reserved for duels.");
            }
        }
    }

    private void checkDuelTimeout() { if(duelA!=null && System.currentTimeMillis()>=duelEndsAt) finishDuel(null,"§eDuel ended: time limit reached. No winner."); }
    private void finishDuel(Player winner, String message) {
        if(duelA==null) return;
        UUID a=duelA,b=duelB; duelA=null; duelB=null; duelists.clear(); duelEndsAt=0;
        for(UUID id:List.of(a,b)) {
            Player p=Bukkit.getPlayer(id); Location loc=returnLocations.remove(id);
            if(p!=null && p.isOnline()) { if(loc!=null && loc.getWorld()!=null) p.teleport(loc); p.sendMessage("§5§lDUEL END §7» "+message); }
        }
        if(winner!=null) Bukkit.broadcastMessage("§5⚔ §dDuel winner: §f"+winner.getName());
    }

    private Location findSafeLocation(World world) {
        int radius=getConfig().getInt("rtp-radius",5000), attempts=getConfig().getInt("rtp-max-attempts",80);
        Random random=new Random(); Location spawn=world.getSpawnLocation();
        for(int i=0;i<attempts;i++) {
            int x=spawn.getBlockX()+random.nextInt(radius*2+1)-radius, z=spawn.getBlockZ()+random.nextInt(radius*2+1)-radius;
            int y=world.getHighestBlockYAt(x,z); if(y<world.getMinHeight() || y+2>=world.getMaxHeight()) continue;
            Block floor=world.getBlockAt(x,y,z), feet=world.getBlockAt(x,y+1,z), head=world.getBlockAt(x,y+2,z);
            if(floor.getType().isSolid() && !floor.isLiquid() && feet.isPassable() && head.isPassable() && !feet.isLiquid() && !head.isLiquid()) return new Location(world,x+0.5,y+1,z+0.5);
        }
        return null;
    }

    private void applyHeldWeaponEffects() {
        for(Player p:Bukkit.getOnlinePlayers()) {
            String main=customId(p.getInventory().getItemInMainHand());
            if("sift_sword".equals(main) || "altar_sword".equals(main)) p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,60,1,true,false,false));
            if("infuse_axe".equals(main) || "altar_sword".equals(main)) p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,60,0,true,false,false));
        }
    }

    private void consumeOne(Player p, EquipmentSlot slot) {
        ItemStack stack=slot==EquipmentSlot.HAND?p.getInventory().getItemInMainHand():p.getInventory().getItemInOffHand();
        if(stack.getAmount()<=1) { if(slot==EquipmentSlot.HAND)p.getInventory().setItemInMainHand(null); else p.getInventory().setItemInOffHand(null); }
        else stack.setAmount(stack.getAmount()-1);
    }
    private String formatDuration(long ms) { long s=ms/1000, h=s/3600, m=(s%3600)/60; return h+"h "+m+"m"; }
    private void loadCooldowns() {
        if(!getDataFolder().exists()) getDataFolder().mkdirs();
        org.bukkit.configuration.file.YamlConfiguration data=org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(new java.io.File(getDataFolder(),"data.yml"));
        for(String key:data.getKeys(false)) try { rtpCooldowns.put(UUID.fromString(key),data.getLong(key)); } catch(IllegalArgumentException ignored) {}
    }
    private void saveCooldowns() {
        org.bukkit.configuration.file.YamlConfiguration data=new org.bukkit.configuration.file.YamlConfiguration();
        rtpCooldowns.forEach((id,time)->data.set(id.toString(),time));
        try { data.save(new java.io.File(getDataFolder(),"data.yml")); } catch(java.io.IOException e) { getLogger().warning("Could not save cooldowns: "+e.getMessage()); }
    }
}
