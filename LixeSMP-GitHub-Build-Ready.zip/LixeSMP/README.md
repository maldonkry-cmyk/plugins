# LixeSMP — Paper 1.21.11

Custom items plugin for Java 25 / Paper 1.21.11.

## Features
- RTP Pearl: right-click for a random safe location; 12-hour per-player cooldown (saved to `plugins/LixeSMP/data.yml`).
- Duel Pearl: right-click to throw; hit a player to teleport both players to the automatically created `LixeDuel` world. The arena blocks break/place/buckets and non-duel players are kept out. 120-minute timeout.
- Sift Sword: right-click dash with cooldown and Speed II while held.
- Infuse Axe: Sharpness VI and Fire Resistance while held.
- Altar Sword: shapeless recipe with RTP Pearl, Duel Pearl, Sift Sword, Infuse Axe, 2 Maces and a Dragon Egg. Has dash, Speed II, Fire Resistance and Sharpness VIII.
- `/lixe give <player> <rtp_pearl|duel_pearl|sift_sword|infuse_axe|altar_sword>` (aliases: `rtp`, `duel`, `sift`, `infuse`, `altar`)
- `/lixe reload`

## Build
Install JDK 25 and Maven 3.9+, then run from this folder:

```bash
mvn clean package
```

The jar will be in `target/LixeSMP-1.0.0.jar`.

## Install
Copy the built jar into your Paper server's `plugins` folder and restart. The plugin creates a separate world named `LixeDuel` automatically. Back up your server before testing.

## Notes
- Custom model data IDs are assigned to each item. A resource pack is required for a truly custom 3D/texture appearance; without it the items use their vanilla base models with custom names/lore and enchantment glint.
- The Duel Pearl is consumed when right-clicked and launches a projectile; it starts the duel only when the projectile hits a player.
- The plugin supports Paper 1.21.11 and Java 25. Compile against the matching Paper API using Maven.
